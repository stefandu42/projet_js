const db = require("../db");
const escape = require("escape-html");
require("dotenv").config();
const bcrypt = require("bcrypt");
const saltRounds = 10;

const { CallingCode } = require("../model/callingCode.js");

const callinCodeModel = new CallingCode();

class User {

  /**
   * Add a resource in the DB and returns the added resource
   * @param {object} body - it contains all required data to create an user ressource
   * @returns {object} the user resource that was created
   */
  async addUser(body) {
    const hashedPassword = await bcrypt.hash(escape(body.password), saltRounds);
    const callingCodeObject = await callinCodeModel.getCallingCodeByCallingCodeWording(body.callingCodeWording);

    if(!callingCodeObject) return 404;

    const idCallingCode = callingCodeObject.id_calling_code;
    let {rows} = await db.query(
      `INSERT INTO stage.users (first_name, surname, email, password, id_calling_code, phone_number)
      VALUES ('${escape(body.firstName)}','${escape(body.surname)}', '${escape(body.email)}', 
      '${hashedPassword}', ${idCallingCode}, '${escape(body.phoneNumber)}') RETURNING id_user as id;`
    );
    
    if (!rows) return 500;

    let user = {
      id_user: rows[0].id,
      firstName: body.firstName,
      surname: body.surname,
      email: body.email,
      password: hashedPassword,
      callingCodeWording : body.callingCodeWording,
      phoneNumber: body.phoneNumber
    };
    return user;
  }


}

module.exports = { User };
