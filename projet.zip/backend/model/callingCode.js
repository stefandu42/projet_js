const db = require("../db");
const escape = require("escape-html");
require("dotenv").config();

class CallingCode {

  /**
   * Returns the resource (calling code) identified by calling code wording
   * @param {number} callinCodeWording - calling code wording of the resource to find
   * @returns {object} the resource found or undefined if the calling code does not exist
   */
   async getCallingCodeByCallingCodeWording(callinCodeWording) {
    const { rows } = await db.query(
      `SELECT * FROM stage.calling_codes WHERE calling_code_wording='${escape(callinCodeWording)}';`
    );
    if (!rows) return;
    return rows[0];
  }


}

module.exports = { CallingCode };
