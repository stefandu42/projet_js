var express = require('express');
var router = express.Router();

const { User } = require("../model/user.js");

const userModel = new User();

router.post('/register', async function(req, res, next) {
  //check if all the fields are there, and filled
  if(
    !req.body ||
    (!req.body.hasOwnProperty("firstName") || req.body.firstName.length === 0) ||
    (!req.body.hasOwnProperty("surname") || req.body.surname.length === 0) ||
    (!req.body.hasOwnProperty("email") || req.body.email.length === 0) ||
    (!req.body.hasOwnProperty("password") || req.body.password.length === 0) ||
    (!req.body.hasOwnProperty("callingCodeWording") || req.body.callingCodeWording.length === 0) ||
    (!req.body.hasOwnProperty("phoneNumber") || req.body.phoneNumber.length === 0)){
      
      return res.status(400).end();
  }
    
  
  const reponseModel = await userModel.addUser(req.body);

  //if the reponse returns an error code
  if(typeof reponseModel==="number") return res.status(reponseModel).end();

  return res.send(reponseModel);
})

module.exports = router;
