DROP SCHEMA IF EXISTS stage CASCADE;
CREATE SCHEMA stage;

CREATE TABLE stage.calling_codes(
    id_calling_code SERIAL PRIMARY KEY,
    calling_code_wording varchar(15) NOT NULL CHECK( calling_code_wording SIMILAR TO '\+_%') UNIQUE,
    country varchar(70) NOT NULL check ( country <> '' ) UNIQUE
);

create table stage.users
(
    id_user  SERIAL NOT NULL PRIMARY KEY ,
    first_name     varchar(50) NOT NULL check ( first_name<>''),
    surname     varchar(50) NOT NULL check ( surname<>''),
    email    varchar(150) NOT NULL CHECK( email SIMILAR TO '%_@_%.__%'),
    password char(60) NOT NULL,
    id_calling_code INTEGER REFERENCES stage.calling_codes (id_calling_code) NOT NULL,
    phone_number varchar(20) NOT NULL check ( phone_number<>'' )
);

INSERT INTO stage.calling_codes (calling_code_wording, country) VALUES ('+32', 'belgium');
INSERT INTO stage.calling_codes (calling_code_wording, country) VALUES ('+33', 'france');
INSERT INTO stage.calling_codes (calling_code_wording, country) VALUES ('+40', 'romania');
