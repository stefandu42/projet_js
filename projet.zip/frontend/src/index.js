const firstName = document.getElementById("firstName");
const surname = document.getElementById("surname");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const callingCodeWording = document.getElementById("callingCodeWording");
const phoneNumber = document.getElementById("phoneNumber");

const register = async (user) => {
    try {
      if(!user) return false;
      const options = {
        method: "POST", 
        body: JSON.stringify(user),
        headers: {
          "Content-Type": "application/json",
        },
      };
  
      const reponse = await fetch("/api/users/register",options);
  
      if (!reponse.ok) {
        throw new Error(
          `fetch error : ${reponse.status} : ${reponse.statusText}`
        );
      }
      const userToReturn = await reponse.json();
      return userToReturn;
    } catch (err) {
      return undefined;
    }
  }

const buttonSubmit = async (e) => {
    e.preventDefault();

    if(firstName.value.length===0){
      console.log("le first name doit etre rempli");
      return;
    }

    if(surname.value.length===0){
      console.log("le surename doit etre rempli");
      return;
    }

    if(email.value.length===0){
      console.log("le email doit etre rempli");
      return;
    }

    if(password.value.length===0){
      console.log("le password doit etre rempli");
      return;
    }

    if(phoneNumber.value.length===0){
      console.log("le phoneNumber doit etre rempli");
      return;
    }

    if(password.value!==confirmPassword.value){
      console.log("les password doivent etre identiques");
      return;
    }

    const user = {
      firstName: firstName.value,
      surname: surname.value,
      email: email.value,
      password: password.value,
      callingCodeWording : callingCodeWording.options[callingCodeWording.selectedIndex].text,
      phoneNumber: phoneNumber.value
    }

    await register(user);
  }
  
document.getElementById("buttonSumbit").addEventListener("click", buttonSubmit);